import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Contributions">
      <p>TODO: Contributions list</p>
    </PageShell>
  );
}
