import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Add Contribution">
      <p>TODO: Contribution wizard</p>
    </PageShell>
  );
}
