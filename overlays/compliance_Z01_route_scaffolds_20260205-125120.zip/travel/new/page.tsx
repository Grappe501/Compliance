import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Add Trip">
      <p>TODO: Travel intake</p>
    </PageShell>
  );
}
