import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Travel">
      <p>TODO: Travel hub</p>
    </PageShell>
  );
}
