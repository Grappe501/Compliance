import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Travel Timeline">
      <p>TODO: Timeline</p>
    </PageShell>
  );
}
