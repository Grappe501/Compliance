import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Filing">
      <p>TODO: Filing prep</p>
    </PageShell>
  );
}
