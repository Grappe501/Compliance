import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Spending Analysis">
      <p>TODO: Analysis</p>
    </PageShell>
  );
}
