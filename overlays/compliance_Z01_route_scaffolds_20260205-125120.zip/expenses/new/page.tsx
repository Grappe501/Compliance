import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Add Expense">
      <p>TODO: Expense wizard</p>
    </PageShell>
  );
}
