import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Expenses">
      <p>TODO: Expenses list</p>
    </PageShell>
  );
}
