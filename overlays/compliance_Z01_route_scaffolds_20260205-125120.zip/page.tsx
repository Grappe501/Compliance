import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Campaign Compliance">
      <p>TODO: Home</p>
    </PageShell>
  );
}
