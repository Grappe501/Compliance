import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Build Map">
      <p>TODO: Build map</p>
    </PageShell>
  );
}
