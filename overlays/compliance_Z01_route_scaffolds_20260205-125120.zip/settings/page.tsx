import PageShell from "@/components/PageShell";

export default function Page() {
  return (
    <PageShell title="Settings">
      <p>TODO: Settings</p>
    </PageShell>
  );
}
